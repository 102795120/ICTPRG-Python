# Made by Tairone Blakeley
x = input("Enter a number: ")
y = int(x)
count = 0
total = 0
while count < int(x):
    count += 1
    print("count: ", count)
    total += count
    print("total: ", total)