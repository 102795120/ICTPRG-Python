# Made by Tairone Blakeley

import random
guesses = 0 # Total guesses, starts at 0, maximum is 7 
value = random.randint(1, 25) # Value picked at random between 1 - 25
guesslog = [] # Array containing user inputs 

print("Guess the number! pick a number between 1 - 25.")

# While loop requiring user input
while guesses < 7: 
    userinput = int(input(">"))
    guesslog.append(userinput)
    # If userinput is higher/lower, it responds accordingly, +1 to total guesses, loops back to beginning
    if userinput < value:
        guesses += 1
        print("It's higher than that!")
        continue
    elif userinput > value:
        guesses += 1
        print("It's lower! than that!")
        continue
    # loop breaks if answer is correct.
    else:
        print("Correct! it only took you " + str(guesses + 1) + " tries!")
        break

# When the user runs out of guesses it will print the correct answer 
if guesses == 7:
    print("You fool, the correct answer was " + str(value) + "!" )
    
# prints out the users previous guesses
print("Previous guesses: " + str(guesslog))
   






