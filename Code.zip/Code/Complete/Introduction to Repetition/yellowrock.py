# Made by Tairone Blakeley
question = "What happens when you throw a yellow rock in the red sea?"
userinput = ""
while (userinput != "It gets wet."):  
    print(question)
    userinput = input(":")
print("Correct.")


    