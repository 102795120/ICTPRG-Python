# Made by Tairone Blakeley
count = 0
while (count < 25):
   count = count + 1  
   print(count)