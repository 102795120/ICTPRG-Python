import subprocess

# runExe takes two parameters and runs CrackMe.exe.  It will return the result of CrackMe.exe as a string
# username: string
# pin: int
# return: string
def runExe(username, pin):
    out = subprocess.check_output(["CrackMe.exe", username, str(pin)], shell=True)
    out = str(out, 'utf-8')
    out = out.strip()
    return out

# Example of how runExe is used (replace this with your solution)

# Imports usernames.csv as an array
data = open("Usernames.csv", "r")
usernames = (data.readlines()) 
# Formats number range as a 4 digit pin, starts attempt count at 0
pin = (["%04d" % x for x in range(9999)]) 
attempts = 0
# While loop repeating the primary function and visibly showing the user progress
while attempts < len(pin):
    for x in pin:
        for y in usernames:
            attempts += 1
            output = runExe(usernames[1], pin[1])
            # X and Y are for the user to see progress
            print(output, "pin:" + x, "User:" + y) 
            # Loop break if all pins combos are exhausted 
            if attempts == len(pin): 
                 break
# Made by Tairone blakeley, unfinished (line 26 need to get it to use each value in the array seperately).          