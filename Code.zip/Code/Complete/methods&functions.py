def helloworld():
    print("Hello World!")

def greeting():
    print("Greetings, " + usrinput)

def addition():
    x = input("Enter a number: ")
    n = int(x)
    z = (sum(range(1, n+1)))
    print("The sum of 1 to",x,"is",z)



helloworld()
print("I'm the addition script! \nIf you're the one i'm looking for, ")
input("press Enter to continue...")

usrinput = str(input("What's your name? "))
accepted = ("alice", "bob")
if usrinput.lower() in accepted:
    greeting()
    addition()
    print("the sum of 1 to 55 is", (sum(range(1, 55+1))))
else:
    print("Nice to meet you",usrinput + ", but you aren't who i'm looking for!")
    