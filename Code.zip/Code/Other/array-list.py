# Made by Tairone Blakeley
def return_max():
    userinput = input(str("Enter number set: "))
    array = len(userinput.split())
    usersplit = userinput.split()
    top = max(usersplit)
    print(top)

def join_list():
    list1 = input(str("Enter list 1: "))
    list1arr = len(list1.split())
    list1split = list1.split()

    list2 = input(str("Enter list 2: "))
    list2arr = len(list2.split())
    list2split = list2.split()

    print(list1 + list2)

def value_digits():
    value = input(str("Enter a number: "))
    array = len(list(value))
    valuelist = (list(value))
    print(valuelist)

return_max()
print("\n")
join_list()
print("\n")
value_digits()

