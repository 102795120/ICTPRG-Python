# Made by Tairone Blakeley
count = 0
while (count < 40):
   count += 2  
   print(count)