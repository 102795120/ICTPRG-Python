# Made by Tairone Blakeley
userinput = input(str("Enter some words: "))
array = len(userinput.split())
usersplit = userinput.split()

print("First word:", usersplit[0])

if array >= 2:
    print("Third word:", usersplit[2])
if array >= 1:
    print("Every other word:", usersplit[1:-1])

print("You entered", str(array), "Words.")







