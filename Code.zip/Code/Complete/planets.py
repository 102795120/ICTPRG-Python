# Made by Tairone Blakeley
userinput = input("How many planets are you away from the sun? ")
userint = int(userinput)
planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]

count = 0
while (count < userint):
    print(planets[count])
    count += 1
print("You are on", (planets[count - 1]))